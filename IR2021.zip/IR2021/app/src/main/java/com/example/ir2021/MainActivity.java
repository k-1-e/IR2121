package com.example.ir2021;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText EditCantidadedit;
    EditText EditCantidadeditINSS;
    EditText EditCantidadeditDeduccion;
    EditText EditCantidadeditrentair;
    EditText EditCantidadeditTotal;

    Button Calcular;
    TextView r;
    TextView rINSS;
    TextView rdeducciones;
    TextView rrentair;
    TextView Salariototal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditCantidadedit = (EditText) findViewById(R.id.EditCantidad);
        EditCantidadeditINSS = (EditText) findViewById(R.id.EditCantidad);
        EditCantidadeditDeduccion = (EditText) findViewById(R.id.EditCantidad);
        EditCantidadeditrentair = (EditText) findViewById(R.id.EditCantidad);
        EditCantidadeditTotal = (EditText) findViewById(R.id.EditCantidad);


        r = (TextView) findViewById(R.id.resultado);
        rINSS = (TextView) findViewById(R.id.resultadoINSS);
        rdeducciones = (TextView) findViewById(R.id.resultadoDeducciones);
        rrentair = (TextView) findViewById(R.id.resultadorentair);
        Salariototal = (TextView) findViewById(R.id.Salariototal);


        Calcular = (Button) findViewById(R.id.Calcular);
        Calcular .setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int cantidad = Integer.parseInt( EditCantidadedit.getText().toString());
        int salariomensualbruto = cantidad / 1;
        r.setText ("Salario mensual bruto " +salariomensualbruto);

        int cantidadINSS = Integer.parseInt( EditCantidadeditINSS.getText().toString());
        int DINSS = ((cantidadINSS *7)/100);
        rINSS.setText ("Deduccion del INSS " +DINSS);

        int cantidadDeduccion = Integer.parseInt( EditCantidadeditDeduccion.getText().toString());
        int Sdeduccion = (cantidadDeduccion - DINSS);
        rdeducciones.setText ("Salario neto (Luego de Deducciones) " +Sdeduccion);


        int Cantidaddeduccion = Integer.parseInt(EditCantidadeditrentair.getText().toString());
        int Salariorentair1 = (Cantidaddeduccion * 12);
        int Salariorentair2 = (int) (Salariorentair1 * 0.0625);
        int Salariorentair3 = (Salariorentair1 - Salariorentair2);
        int Salariorentair4 = ((Salariorentair3 *15)/100);
        int Salariorentair5 = (int) ((Salariorentair4 *0.2)+15000);
        int Salariorentair = (Salariorentair5 /12);
        rrentair.setText ("Deducción Impuesto sobre la Renta (IR) " +Salariorentair);

        int salariototal = Integer.parseInt( EditCantidadeditTotal.getText().toString());
        int Stotal = (salariomensualbruto - Salariorentair);
        Salariototal.setText ("Salario neto (Luego de Deducciones) " +Stotal);

    }

}